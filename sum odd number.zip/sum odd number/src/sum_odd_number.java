
public class sum_odd_number {

	public static void main(String[] args) {
	int sum = 0;
	for (int i = 1; i <= 500; i++) {
		if (i % 2 == 1) {
			sum = sum + i;
		}
	}
	 System.out.println("Sum of All The Odd Number:"+sum);
}
}
